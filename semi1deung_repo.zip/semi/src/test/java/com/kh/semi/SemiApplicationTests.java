package com.kh.semi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemiApplicationTests {

	@Test
	void contextLoads() {
	}

}
