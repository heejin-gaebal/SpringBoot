package com.kh.semi.customer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
@RequestMapping("customer")
public class CustomerController {
    @GetMapping("insert")
    public String customerInsert(){
        return "customer/insert";
    }

    @RequestMapping("list")
    public String customerList(){
        return "customer/list";
    }

}
