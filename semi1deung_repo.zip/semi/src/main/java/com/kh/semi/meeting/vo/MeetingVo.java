package com.kh.semi.meeting.vo;

import lombok.Data;

@Data
public class MeetingVo {

    private String meetingNo;
    private String meetingName;
    private String meetingStartDate;
    private String meetingDelYn;
    private String meetingCustomerNo;
    private String meetingMemberEmpId;
    private String meetingStatus;

}
