package com.kh.semi.member.vo;

import lombok.Data;

@Data
public class MemberVo {

    private String memberEmpId;
    private String memberId;
    private String memberPwd;
    private String memberName;
    private String memberRrn;
    private String memberNick;
    private String memberPhonenumber;
    private String memberEmail;
    private String memberAuthNo;
    private String memberAuthTime;
    private String memberAddress;
    private String memberProfilePictureUrl;
    private String memberIsAdmin;
    private String memberHireDate;
    private String memberDelYn;
    private String memberDelDate;
    private String memberFailedLoginAttempt;
    private String memberNeedLoginCertification;
    private String memberIsRest;
    private String memberManagerEmpId;
    private String memberDepartmentNo;
    private String memberJobNo;

}
