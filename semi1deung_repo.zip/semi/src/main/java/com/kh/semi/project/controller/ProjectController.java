package com.kh.semi.project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("project")
public class ProjectController {

    @GetMapping("insert")
    public void insert(){}

    @GetMapping("list")
    public void list(){}

    @GetMapping("detail/{no}")
    public String detail(@PathVariable String no){return "project/detail";}
}
