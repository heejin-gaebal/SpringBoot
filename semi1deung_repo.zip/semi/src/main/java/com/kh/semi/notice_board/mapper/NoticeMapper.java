package com.kh.semi.notice_board.mapper;

import com.kh.semi.notice_board.vo.NoticeVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface NoticeMapper {
    @Insert("""
            INSERT INTO NOTICE_BOARD (
              NOTICE_NO,
              NOTICE_TITLE,
              NOTICE_CONTENT,
              NOTICE_WRITER_EMP_ID
            ) VALUES (
              SEQ_NOTICE_BOARD.NEXTVAL,
              #{noticeTitle},
              #{noticeContent},
              #{noticeWriterEmpId}
            )
            """)
    int insert(NoticeVo vo);

    @Select("""
            SELECT
                NOTICE_NO
                , NOTICE_TITLE
                , NOTICE_CREATED_DATE
                , NOTICE_HIT
                , NOTICE_WRITER_EMP_ID
            FROM NOTICE_BOARD
            WHERE NOTICE_DEL_YN = 'N'
            """)
    List<NoticeVo> list();
}
