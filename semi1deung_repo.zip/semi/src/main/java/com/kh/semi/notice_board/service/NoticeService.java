package com.kh.semi.notice_board.service;

import com.kh.semi.notice_board.mapper.NoticeMapper;
import com.kh.semi.notice_board.vo.NoticeVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class NoticeService {
    private final NoticeMapper noticeMapper;

    public int insert(NoticeVo vo) {
        return noticeMapper.insert(vo);
    }

    public List<NoticeVo> list() {
        return noticeMapper.list();
    }
}
