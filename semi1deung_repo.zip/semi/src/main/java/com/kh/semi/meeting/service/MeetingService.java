package com.kh.semi.meeting.service;

import com.kh.semi.meeting.mapper.MeetingMapper;
import com.kh.semi.meeting.vo.MeetingVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class MeetingService {

    private final MeetingMapper meetingMapper;



}
