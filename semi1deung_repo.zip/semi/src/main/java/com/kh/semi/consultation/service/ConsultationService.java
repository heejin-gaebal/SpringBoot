package com.kh.semi.consultation.service;

import com.kh.semi.consultation.mapper.ConsultationMapper;
import com.kh.semi.consultation.vo.ConsultationVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class ConsultationService {

    private static ConsultationMapper consultationMapper;

    public static int consultationInsert() {
        return 0;
    }

    public int consultationInsert(ConsultationVo consultationVo) {
        return consultationMapper.consultationInsert(consultationVo);
    }

    public static List<ConsultationVo> consultationList(String consultationNo) {
        return consultationMapper.consultationList(consultationNo);
    }

}
