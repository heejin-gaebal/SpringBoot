package com.kh.semi.consultation.api;

import com.kh.semi.consultation.service.ConsultationService;
import com.kh.semi.consultation.vo.ConsultationVo;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/consultation")
@RequiredArgsConstructor
public class ConsultationApiController {

    private final ConsultationService consultationService;

    @PostMapping
    public int consultationInsert(@RequestBody ConsultationService consultationService){
        int result = ConsultationService.consultationInsert();
        return result;
    }

    @GetMapping
    public List<ConsultationVo> consultationList(String consultNo){
        List<ConsultationVo> consultationVoList = ConsultationService.consultationList(consultNo);
        return consultationVoList;
    }

}
