package com.kh.semi.task.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("task")
public class TaskController {

    //insert
    @GetMapping("insert")
    public void insert(){}

    //selectList
    //게시글 목록
    @GetMapping("list/*")
    public String selectList(){
        return "task/list";
    }

    //selectOne
    @GetMapping("selectOne")
    public void selectOne(){}

    //update
    @GetMapping("update")
    public void update(){}
}
