package com.kh.semi.member.service;

import com.kh.semi.member.mapper.MemberMapper;
import com.kh.semi.member.vo.MemberVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class MemberLoginAttemptService {

    private final MemberMapper mapper;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void increaseLoginAttempt(MemberVo vo) {
        int result = mapper.increaseLoginAttempt(vo);
        if(result != 1){
            throw new IllegalStateException("로그인 실패 횟수 증가 실패");
        }
    }
}