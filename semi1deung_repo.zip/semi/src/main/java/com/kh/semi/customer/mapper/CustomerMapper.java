package com.kh.semi.customer.mapper;

import com.kh.semi.customer.vo.CustomerVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CustomerMapper {

    @Insert("""
            INSERT INTO CUSTOMER
                        (
                        CUSTOMER_NO
                        , CUSTOMER_GRADE
                        , CUSTOMER_NAME
                        , CUSTOMER_PHONE
                        , CUSTOMER_EMAIL
                        , CUSTOMER_CONTACT_EMP_ID
                        )
                        VALUES
                        (
                            SEQ_CUSTOMER.NEXTVAL
                            , #{customerGrade}
                            , #{customerName}
                            , #{customerPhone}
                            , #{customerEmail}
                            , #{customerContactEmpId}
                        )
            """)
    int customerInsert(CustomerVo customerVo);

    @Select("""
            SELECT
                        CUSTOMER_NO
                            ,CUSTOMER_GRADE
                            ,CUSTOMER_NAME
                            ,CUSTOMER_PHONE
                            ,CUSTOMER_EMAIL
                            ,CUSTOMER_CONTACT_EMP_ID
                        FROM CUSTOMER
                        WHERE CUSTOMER_NO = #{customerNo}
                        AND DEL_YN = 'N'
            """)
    List<CustomerVo> customerList(@Param("customerNo") String customerNo);
}
