package com.kh.semi.project.mapper;

import com.kh.semi.project.vo.ProjectVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ProjectMapper {

    @Insert("""
            INSERT INTO PROJECT (
                PROJECT_NO,
                PROJECT_DEPARTMENT_NO,
                PROJECT_DEPARTMENT_REFERENCE_NO,
                PROJECT_PRIORITY,
                PROJECT_STATUS,
                PROJECT_NAME,
                PROJECT_CREATOR,
                PROJECT_MANAGER,
                PROJECT_ENDED_DATE
            ) VALUES (
                SEQ_PROJECT.NEXTVAL,
                #{projectDepartmentNo},
                #{projectDepartmentReferenceNo},
                #{projectPriority},
                #{projectStatus},
                #{projectName},
                #{projectCreator},
                #{projectManager},
                SYSDATE + INTERVAL '3' MONTH
            )
            """)
    int projectInsert(ProjectVo projectVo);

    @Select("""
            SELECT
                PROJECT_NO
                ,PROJECT_DEPARTMENT_NO
                ,PROJECT_DEPARTMENT_REFERENCE_NO
                ,PROJECT_PRIORITY
                ,PROJECT_STATUS
                ,PROJECT_NAME
                ,PROJECT_CREATOR
                ,PROJECT_MANAGER
                ,PROJECT_CREATED_DATE
                ,PROJECT_ENDED_DATE
                ,PROJECT_DEL_YN
            FROM
                PROJECT
            ORDER BY
                PROJECT_NO
            """)
    List<ProjectVo> projectList();

    @Select("""
            SELECT
                PROJECT_NO,
                PROJECT_DEPARTMENT_NO,
                PROJECT_DEPARTMENT_REFERENCE_NO,
                PROJECT_PRIORITY,
                PROJECT_STATUS,
                PROJECT_NAME,
                PROJECT_CREATOR,
                PROJECT_MANAGER,
                PROJECT_CREATED_DATE,
                PROJECT_ENDED_DATE,
                PROJECT_DEL_YN
            FROM
                PROJECT
            WHERE
                PROJECT_NO = #{projectNo};
            """)
    ProjectVo projectSelectOneByNo(String no);
}
