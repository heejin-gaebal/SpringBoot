package com.kh.semi.consultation.mapper;

import com.kh.semi.consultation.vo.ConsultationVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ConsultationMapper {

    @Insert("""
            INSERT INTO CONSULTATION
                (
                CONSULT_NO
                , CONSULT_TITLE
                , CONSULT_CONTENT
                , CONSULT_ENROLL_TIME
                , CONSULT_FIRST_RESPONSE_TIME
                , CONSULT_SATISFACTION_SCORE
                , CONSULT_CUSTOMER_NO
                , CONSULT_MEMBER_EMP_ID
                , CONSULT_STATUS
                , CONSULT_PRIORITY
                )
                VALUES
                (
                SEQ_CONSULTATION.NEXTVAL
                , #{consultTitle}
                , #{consultContent}
                , #{consultEnrollTime}
                , #{consultFirstResponseTime}
                , #{consultSatisfactionScore}
                , #{consultCustomerNo}
                , #{consultMemberEmpId}
                , #{consultStatus}
                , #{consultPriority}
                )
            """)
    int consultationInsert(ConsultationVo consultationVo);

    @Select("""
            SELECT
                CONSULT_NO
                , CONSULT_TITLE
                , CONSULT_CONTENT
                , CONSULT_ENROLL_TIME
                , CONSULT_FIRST_RESPONSE_TIME
                , CONSULT_SATISFACTION_SCORE
                , CONSULT_CUSTOMER_NO
                , CONSULT_MEMBER_EMP_ID
                , CONSULT_STATUS
                , CONSULT_PRIORITY
                FROM CONSULTATION
                WHERE CONSULTATION_NO = #{consultNo}
                AND DEL_YN = 'N'
            """)
    List<ConsultationVo> consultationList(@Param("consultNo") String consultNo);
}
