package com.kh.semi.customer.api;

import com.kh.semi.customer.service.CustomerService;
import com.kh.semi.customer.vo.CustomerVo;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/customer")
public class CustomerApiController {

    private final CustomerService service;



}

