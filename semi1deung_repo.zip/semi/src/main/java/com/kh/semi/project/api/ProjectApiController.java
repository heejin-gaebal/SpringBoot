package com.kh.semi.project.api;


import com.kh.semi.project.service.ProjectService;
import com.kh.semi.project.vo.ProjectVo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/project")
public class ProjectApiController {

    private final ProjectService projectService;

    @PostMapping
    public ResponseEntity<Integer> projectInsert(@RequestBody ProjectVo projectVo){
        int result = projectService.projectInsert(projectVo);
        return ResponseEntity.ok().body(result);
    }

    @GetMapping
    public List<ProjectVo> projectList(){
        List<ProjectVo> projectVoList = projectService.projectList();
        return projectVoList;
    }

    @GetMapping("{no}")
    public ProjectVo projectSelectOneByNo(@PathVariable String no){
        ProjectVo projectVo = projectService.projectSelectOneByNo(no);
        return projectVo;
    }

}
