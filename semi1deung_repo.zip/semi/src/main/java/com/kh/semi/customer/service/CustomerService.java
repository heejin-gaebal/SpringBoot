package com.kh.semi.customer.service;

import com.kh.semi.customer.mapper.CustomerMapper;
import com.kh.semi.customer.vo.CustomerVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class CustomerService {

    private final CustomerMapper customerMapper;

    public int customerInsert(CustomerVo customerVo) {
        return customerMapper.customerInsert(customerVo);
    }

    public List<CustomerVo> customerList(String customerNo) {
        return customerMapper.customerList(customerNo);
    }

}
