package com.kh.semi.customer.vo;

import lombok.Data;

@Data
public class CustomerVo {

    private String customerNo;
    private String customerGrade;
    private String customerName;
    private String customerPhone;
    private String customerEmail;
    private String customerDelYn;
    private String customerContactEmpId;
    private String customerTypeNo;


}
