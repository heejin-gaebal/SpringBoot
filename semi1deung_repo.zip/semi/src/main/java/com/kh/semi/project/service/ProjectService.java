package com.kh.semi.project.service;

import com.kh.semi.project.mapper.ProjectMapper;
import com.kh.semi.project.vo.ProjectVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class ProjectService {

    private final ProjectMapper projectMapper;

    public int projectInsert(ProjectVo projectVo) {
        return projectMapper.projectInsert(projectVo);
    }

    public List<ProjectVo> projectList() {
        return projectMapper.projectList();
    }

    public ProjectVo projectSelectOneByNo(String no) {
        return projectMapper.projectSelectOneByNo(no);
    }
}
