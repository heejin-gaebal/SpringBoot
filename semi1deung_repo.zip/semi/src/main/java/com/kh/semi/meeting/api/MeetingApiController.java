package com.kh.semi.meeting.api;

import com.kh.semi.consultation.service.ConsultationService;
import com.kh.semi.consultation.vo.ConsultationVo;
import com.kh.semi.meeting.service.MeetingService;
import com.kh.semi.meeting.vo.MeetingVo;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/meeting")
@RequiredArgsConstructor
public class MeetingApiController {
    private final MeetingService meetingService;



}
