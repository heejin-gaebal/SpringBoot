package com.kh.semi.notice_board.vo;

import lombok.Data;

@Data
public class NoticeVo {
    private String noticeNo;
    private String noticeTitle;
    private String noticeContent;
    private String noticeCreatedDate;
    private String noticeHit;
    private String noticeDelYn;
    private String noticeWriterEmpId;
    private String noticeLastChangedDate;
}
