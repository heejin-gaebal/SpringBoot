package com.kh.semi.member.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MemberController {

}
