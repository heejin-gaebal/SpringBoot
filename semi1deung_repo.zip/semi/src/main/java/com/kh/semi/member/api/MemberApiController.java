package com.kh.semi.member.api;

import com.kh.semi.member.service.MemberService;
import com.kh.semi.member.vo.MemberVo;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/member")
public class MemberApiController {

    private final MemberService service;

    //회원가입
    @PostMapping("/join")
    public ResponseEntity join(@RequestBody MemberVo vo, HttpSession session){
        MemberVo loginMember = (MemberVo) session.getAttribute("loginMember");
        service.join(vo, loginMember);
        return ResponseEntity.ok().build();
    }

    //로그인
    @PostMapping("/login")
    public ResponseEntity login(@RequestBody MemberVo vo, HttpSession session){
        MemberVo loginMember = service.login(vo);
        session.setAttribute("loginMember", loginMember);
        return ResponseEntity.ok().build();
    }

    //로그아웃
    @GetMapping
    public ResponseEntity logout(HttpSession session){
        session.invalidate();
        return ResponseEntity.ok().build();
    }

    //닉네임 유효성 검사
    @PostMapping("/checkNick")
    public ResponseEntity<Map<String, Object>> checkNick(@RequestBody MemberVo vo){
        Map<String, Object> resultMap = new HashMap<>();
        String newNick = vo.getMemberNick();
        // 금칙어 리스트
        List<String> bannedWords = List.of("바보", "병신", "fuck", "shit", "admin");
        // 금칙어 포함 여부 검사
        for (String word : bannedWords) {
            if (newNick.toLowerCase().contains(word.toLowerCase())) {
                resultMap.put("valid", false);
                resultMap.put("checkNickMsg", "사용할 수 없는 단어가 포함되어 있습니다.");
                return ResponseEntity.ok().body(resultMap);
            }
        }
        // 형식 체크
        if (!newNick.matches("^[가-힣a-zA-Z0-9]{2,20}$")) {
            resultMap.put("valid", false);
            resultMap.put("checkNickMsg", "닉네임은 특수문자를 제외한 2~20자리만 사용 가능합니다.");
            return ResponseEntity.ok().body(resultMap);
        }
        MemberVo checkNick = service.checkNick(vo);
        if (checkNick != null) {
            resultMap.put("valid", false);
            resultMap.put("checkNickMsg", "이미 존재하는 닉네임입니다.");
            return ResponseEntity.ok().body(resultMap);
        }
        resultMap.put("valid", true);
        resultMap.put("checkNickMsg", "사용 가능한 닉네임입니다.");
        return ResponseEntity.ok().body(resultMap);
    }

    //아이디 유효성 검사
    @PostMapping("/checkId")
    public ResponseEntity<Map<String, Object>> checkId(@RequestBody MemberVo vo){
        Map<String, Object> resultMap = new HashMap<>();
        String newId = vo.getMemberId();
        // 공백 포함 여부
        if (newId.contains(" ")) {
            resultMap.put("valid", false);
            resultMap.put("checkIdMsg", "아이디에 공백을 포함할 수 없습니다.");
            return ResponseEntity.ok().body(resultMap);
        }
        // 형식 체크 (영문+숫자, 5~16자)
        if (!newId.matches("^[a-zA-Z0-9]{5,16}$")) {
            resultMap.put("valid", false);
            resultMap.put("checkIdMsg", "아이디는 5~16자의 영문과 숫자만 사용 가능합니다.");
            return ResponseEntity.ok().body(resultMap);
        }
        // 중복 체크
        MemberVo checkId = service.checkId(vo);
        if (checkId != null) {
            resultMap.put("valid", false);
            resultMap.put("checkIdMsg", "이미 존재하는 아이디입니다.");
            return ResponseEntity.ok().body(resultMap);
        }
        resultMap.put("valid", true);
        resultMap.put("checkIdMsg", "사용 가능한 아이디입니다.");
        return ResponseEntity.ok().body(resultMap);
    }

    //비밀번호 유효성 검사
    @PostMapping("/checkPwd")
    public ResponseEntity<Map<String, Object>> checkPwd(@RequestBody MemberVo vo){
        Map<String, Object> resultMap = new HashMap<>();
        String newPwd = vo.getMemberPwd();
        // 공백 포함 여부
        if (newPwd.contains(" ")) {
            resultMap.put("valid", false);
            resultMap.put("checkPwdMsg", "비밀번호에 공백을 포함할 수 없습니다.");
            return ResponseEntity.ok().body(resultMap);
        }
        // 형식 체크 (영문 대소문자 + 숫자 + 특수문자 포함, 8~20자)
        if (!newPwd.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,20}$")) {
            resultMap.put("valid", false);
            resultMap.put("checkPwdMsg", "영문 대소문자, 숫자, 특수문자(@,$,!,%,*,?,&)를 포함한 8~20자여야 합니다.");
            return ResponseEntity.ok().body(resultMap);
        }
        resultMap.put("valid", true);
        return ResponseEntity.ok().body(resultMap);
    }

}
