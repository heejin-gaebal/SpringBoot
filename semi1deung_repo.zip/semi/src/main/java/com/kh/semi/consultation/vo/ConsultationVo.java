package com.kh.semi.consultation.vo;

import lombok.Data;

@Data
public class ConsultationVo {

    private String consultNo;
    private String consultTitle;
    private String consultContent;
    private String consultEnrollTime;
    private String consultFirstResponseTime;
    private String consultSatisfactionScore;
    private String consultDelYn;
    private String consultCustomerNo;
    private String consultMemberEmpId;
    private String consultStatus;
    private String consultPriority;

}
