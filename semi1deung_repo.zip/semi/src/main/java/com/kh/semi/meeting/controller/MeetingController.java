package com.kh.semi.meeting.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("meeting")
public class MeetingController {

    @RequestMapping("insert")
    public void meetingInsert(){

    }

    @RequestMapping("detail/*")
    public String detail() {
        return "meeting/detail";
    }

}
