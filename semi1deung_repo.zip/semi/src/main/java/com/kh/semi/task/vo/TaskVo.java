package com.kh.semi.task.vo;

import lombok.Data;

@Data
public class TaskVo {
    private String taskNo;
    private String taskProjectNo;
    private String taskName;
    private String taskDepartmentNo;
    private String taskCreator;
    private String taskManager;
    private String taskPriority;
    private String taskCreatedDate;
    private String taskEndedDate;
    private String taskStatus;
    private String taskDelYn;
    private String taskParentTaskNo;
}
