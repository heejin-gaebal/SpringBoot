package com.kh.semi.task.mapper;

import com.kh.semi.task.vo.TaskVo;
import com.kh.semi.util.page.PageVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface TaskMapper {
    @Insert("""
            INSERT INTO TASK (
              TASK_NO,
              TASK_PROJECT_NO,
              TASK_NAME,
              TASK_DEPARTMENT_NO,
              TASK_CREATOR,
              TASK_MANAGER,
              TASK_PRIORITY,
              TASK_ENDED_DATE,
              TASK_STATUS
            ) VALUES (
              SEQ_TASK.NEXTVAL,
              #{taskProjectNo},
              #{taskName},
              #{taskDepartmentNo},
              #{taskCreator},
              #{taskManager},
              #{taskPriority},
              #{taskEndedDate},
              #{taskStatus}
            )
            """)
    int insert(TaskVo vo);

    @Select("""
            SELECT
                TASK_NO,
                TASK_NAME,
                TASK_PARENT_TASK_NO,
                TASK_PRIORITY,
                TASK_STATUS,
                TASK_CREATED_DATE,
                TASK_ENDED_DATE
            FROM
                TASK
            WHERE
                TASK_PROJECT_NO = (
                    SELECT PROJECT_NO FROM PROJECT WHERE PROJECT_NAME = #{projectName}
                )
            ORDER BY
                TASK_PARENT_TASK_NO,
                TASK_NO
            """)
    List<TaskVo> selectList();

    //게시글 카운트
    @Select("""
            SELECT
                COUNT(TASK_NO)
            FROM TASK
            WHERE TASK_DEL_YN = 'N'
            """)
    int getBoardCount();

    @Select("""
            SELECT
                TASK_NO
                ,TASK_PROJECT_NO
                ,TASK_NAME
                ,TASK_DEPARTMENT_NO
                ,TASK_CREATOR
                ,TASK_MANAGER
                ,TASK_PRIORITY
                ,TASK_CREATED_DATE
                ,TASK_ENDED_DATE
                ,TASK_STATUS
                ,TASK_DEL_YN
                ,TASK_PARENT_TASK_NO
            FROM TASK
            ORDER BY TASK_NO DESC
            OFFSET #{offset} ROWS FETCH NEXT #{boardLimit} ROW ONLY
            """)
    List<TaskVo> paging(PageVo taskPageVo);
}
