package com.kh.semi.task.service;

import com.kh.semi.task.mapper.TaskMapper;
import com.kh.semi.task.vo.TaskVo;
import com.kh.semi.util.page.PageVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class TaskService {
    private final TaskMapper taskMapper;

    public int insert(TaskVo vo) {
        return taskMapper.insert(vo);
    }

    public List<TaskVo> selectList() {
        return taskMapper.selectList();
    }

    public int getBoardCount() {
        return taskMapper.getBoardCount();
    }

    public List<TaskVo> paging(PageVo taskPageVo) {
        return taskMapper.paging(taskPageVo);
    }


//    public TaskVo listOne(String no) {
//        return taskMapper.listOne(no);
//    }
}
