package com.kh.semi.member.service;

import com.kh.semi.member.mapper.MemberMapper;
import com.kh.semi.member.vo.MemberVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class MemberService {

    private final MemberMapper mapper;
    private final MemberLoginAttemptService memberLoginAttemptService;

    public void join(MemberVo vo, MemberVo loginMember) {
        //어드민 확인
        String isAdmin = loginMember.getMemberIsAdmin();
        if(!isAdmin.equals("Y")){
            throw new IllegalStateException("[MEMBER-001] loginMember is not admin");
        }
        int result = mapper.join(vo);
        if(result != 1 ){
            throw new IllegalStateException("[MEMBER-002] join error");
        }
    }

    public MemberVo login(MemberVo vo) {
        //아이디 존재여부 체크
        MemberVo checkId = mapper.checkId(vo);
        if(checkId == null){
            throw new IllegalStateException("[MEMBER-003] there is no member id");
        }
        //로그인 실패 횟수 검증
        int failedLoginAttempt = Integer.parseInt(checkId.getMemberFailedLoginAttempt());
        if(failedLoginAttempt >= 5) {
            throw new IllegalStateException("[MEMBER-004] 로그인 실패 5회: 관리자에게 문의바람");
        }
        //비밀번호 검증
        MemberVo checkPwd = mapper.checkPwd(vo);
        if(checkPwd == null){
            memberLoginAttemptService.increaseLoginAttempt(vo);
            throw new IllegalStateException("[MEMBER-005] wrong password");
        }
        //인증필요여부
        String needLoginCertification = checkPwd.getMemberNeedLoginCertification();
        if(needLoginCertification.equals("Y")){
            //인증절차(미구현)
            System.out.println(needLoginCertification);
        }

        //로그인
        MemberVo loginMember = mapper.login(vo);
        //로그인 시도 초기화
        int reset = mapper.resetLoginAttempt(vo);
        if(reset != 1){
            throw new IllegalStateException("로그인 실패 횟수 초기화 에러");
        }
        return loginMember;
    }

    public MemberVo checkNick(MemberVo vo) {
        MemberVo checkNick = mapper.checkNick(vo);
        return checkNick;
    }

    public MemberVo checkId(MemberVo vo) {
        MemberVo checkId = mapper.checkId(vo);
        return checkId;
    }

}
