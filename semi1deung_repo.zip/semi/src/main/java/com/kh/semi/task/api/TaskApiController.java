package com.kh.semi.task.api;

import com.kh.semi.project.vo.ProjectVo;
import com.kh.semi.task.service.TaskService;
import com.kh.semi.task.vo.TaskVo;
import com.kh.semi.util.page.PageVo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/task")
@RequiredArgsConstructor
public class TaskApiController {
    private final TaskService taskService;

    //insert
    @PostMapping
    public ResponseEntity<Integer> insert(@RequestBody TaskVo vo){
//        ProjectVo projectVo = new ProjectVo();
//        vo.setTaskProjectNo(projectVo.getProjectNo());
        vo.setTaskProjectNo("16");
        int result = taskService.insert(vo);
        return ResponseEntity.ok().body(result);
    }
    
    //페이징
    @GetMapping("{currentPage}")
    public ResponseEntity<Map<String, Object>> selectList(@PathVariable int currentPage){
        int listCount = taskService.getBoardCount();
        int pageLimit = 10;
        int boardLimit = 10;

        PageVo pageVo = new PageVo(listCount, pageLimit, boardLimit, currentPage);
        List<TaskVo> voList = taskService.paging(pageVo);

        Map<String, Object> map = new HashMap<>();
        map.put("taskVoList", voList);
        map.put("taskPageVo", pageVo);

        return ResponseEntity.ok().body(map);

    }

    //listOne
//    @GetMapping("{no}")
//    public ResponseEntity<TaskVo> listOne(@PathVariable String no){
//        TaskVo vo = taskService.listOne(no);
//        return ResponseEntity.ok().body(vo);
//    }
    //update
//    @PutMapping
//    public ResponseEntity<TaskVo> update(@RequestBody TaskVo vo){
//        int result = taskService.update(vo);
//        return ResponseEntity.ok().body(vo);
//    }
//
//    //delete
//    @DeleteMapping
//    public void delete(@RequestBody TaskVo vo){
//        int result = taskService.delete(vo);
//    }
}
