package com.kh.semi.consultation.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("consultation")
public class ConsultationController {

    @RequestMapping("insert")
    public void consultationInsert(){}

    @RequestMapping("list")
    public void consultationList(){}

    @RequestMapping("detail/*")
    public String consultationDetail() {
        return "consultation/detail";
    }

}
