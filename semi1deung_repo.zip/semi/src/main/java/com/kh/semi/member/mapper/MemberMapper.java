package com.kh.semi.member.mapper;

import com.kh.semi.member.vo.MemberVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface MemberMapper {

    @Insert("""
            INSERT INTO MEMBER
            (
                MEMBER_EMP_ID
                , MEMBER_ID
                , MEMBER_PWD
                , MEMBER_NAME
                , MEMBER_EMAIL
                , MEMBER_RRN
                , MEMBER_PHONENUMBER
                , MEMBER_MANAGER_EMP_ID
                , MEMBER_DEPARTMENT_NO
                , MEMBER_JOB_NO
                , MEMBER_NICK
                , MEMBER_ADDRESS
                , MEMBER_PROFILE_PICTURE_URL
            )
            VALUES
            (
                'EMP' || TO_CHAR(SYSDATE, 'YY') || LPAD(SEQ_MEMBER.NEXTVAL, 4, '0')
                , #{memberId}
                , #{memberPwd}
                , #{memberName}
                , #{memberEmail}
                , #{memberRrn}
                , #{memberPhonenumber}
                , #{memberManagerEmpId}
                , #{memberDepartmentNo}
                , #{memberJobNo}
                , NVL(#{memberNick}, NULL)
                , NVL(#{memberAddress}, NULL)
                , NVL(#{memberProfilePictureUrl}, NULL)
            )
            """)
    int join(MemberVo vo);

    @Select("""
            SELECT
                MEMBER_EMP_ID
                , MEMBER_ID
                , MEMBER_NAME
                , MEMBER_RRN
                , MEMBER_NICK
                , MEMBER_PHONENUMBER
                , MEMBER_EMAIL
                , MEMBER_ADDRESS
                , MEMBER_PROFILE_PICTURE_URL
                , MEMBER_IS_ADMIN
                , MEMBER_HIRE_DATE
                , MEMBER_MANAGER_EMP_ID
                , MEMBER_DEPARTMENT_NO
                , MEMBER_JOB_NO
            FROM MEMBER
            WHERE MEMBER_ID = #{memberId}
            AND MEMBER_PWD = #{memberPwd}
            AND MEMBER_DEL_YN = 'N'
            """)
    MemberVo login(MemberVo vo);

    @Select("""
            SELECT
                MEMBER_ID
                , MEMBER_FAILED_LOGIN_ATTEMPT
            FROM MEMBER
            WHERE MEMBER_ID = #{memberId}
            """)
    MemberVo checkId(MemberVo vo);

    @Select("""
            SELECT MEMBER_NEED_LOGIN_CERTIFICATION
            FROM MEMBER
            WHERE MEMBER_ID = #{memberId}
            AND MEMBER_PWD = #{memberPwd}
            """)
    MemberVo checkPwd(MemberVo vo);

    @Update("""
            UPDATE MEMBER
                SET MEMBER_FAILED_LOGIN_ATTEMPT = MEMBER_FAILED_LOGIN_ATTEMPT + 1
            WHERE MEMBER_ID = #{memberId}
            """)
    int increaseLoginAttempt(MemberVo vo);

    @Update("""
            UPDATE MEMBER
                SET MEMBER_FAILED_LOGIN_ATTEMPT = 0
            WHERE MEMBER_ID = #{memberId}
            """)
    int resetLoginAttempt(MemberVo vo);

    @Select("""
            SELECT MEMBER_NICK
            FROM MEMBER
            WHERE MEMBER_NICK = #{memberNick}
            """)
    MemberVo checkNick(MemberVo vo);
}
