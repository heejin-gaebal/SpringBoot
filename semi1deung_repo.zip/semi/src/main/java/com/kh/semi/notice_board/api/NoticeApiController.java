package com.kh.semi.notice_board.api;

import com.kh.semi.member.vo.MemberVo;
import com.kh.semi.notice_board.service.NoticeService;
import com.kh.semi.notice_board.vo.NoticeVo;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/notice_board")
@RequiredArgsConstructor
public class NoticeApiController {
    private final NoticeService noticeService;

    //insert
    @PostMapping
    public ResponseEntity<Integer> insert(@RequestBody NoticeVo vo, HttpSession session){
        MemberVo memberVo = (MemberVo) session.getAttribute("loginMember");
        vo.setNoticeWriterEmpId(memberVo.getMemberEmpId());
        int result = noticeService.insert(vo);

        return ResponseEntity.ok().body(result);
    }

    @GetMapping
    public ResponseEntity<List<NoticeVo>> list(){
        List<NoticeVo> voList = noticeService.list();
        return ResponseEntity.ok().body(voList);
    }

}
