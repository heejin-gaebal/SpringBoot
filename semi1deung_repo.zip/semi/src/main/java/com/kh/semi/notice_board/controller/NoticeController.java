package com.kh.semi.notice_board.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("notice_board")
public class NoticeController {

    //insert
    @GetMapping("insert")
    public void insert(){}

    //list
    @GetMapping("list")
    public void list(){}

}
