package com.kh.semi.project.vo;

import lombok.Data;

@Data
public class ProjectVo {
    private String projectNo;
    private String projectDepartmentNo;
    private String projectDepartmentReferenceNo;
    private String projectPriority;
    private String projectStatus;
    private String projectName;
    private String projectCreator;
    private String projectManager;
    private String projectCreatedDate;
    private String projectEndedDate;
    private String projectDelYn;
}
