function projectList(){
    // const pno = location.href.split("/").pop();
    const url = `http://127.0.0.1:8080/api/project`;

    fetch(url)
    .then(resp =>resp.json())
    .then(projectVoList =>{
        const tbodyTag = document.querySelector("tbody");

        let str = "";
        for(const projectVo of projectVoList){
            str += `
            <tr onclick="location.href='/project/detail/${projectVo.projectNo}'">
                <td>${projectVo.projectNo}</td>
                <td>${projectVo.projectName}</td>
                <td>${projectVo.projectDepartmentNo}</td>
                <td>${projectVo.projectDepartmentReferenceNo}</td>
                <td>${projectVo.projectPriority}</td>
                <td>${projectVo.projectStatus}</td>
                <td>${projectVo.projectCreator}</td>
                <td>${projectVo.projectManager}</td>
                <td>${projectVo.projectCreatedDate}</td>
                <td>${projectVo.projectEndedDate}</td>
                <td>${projectVo.projectDelYn}</td>
            </tr>   
            `;
        }
        tbodyTag.innerHTML = str;
    })
    .catch(err=>{
        throw new Error(err);
    })
    ;

}

projectList();