function projectInsert(){

    const projectName = document.querySelector("input[name=project-name]").value;
    const projectDepartmentNo = document.querySelector("input[name=project-department-no]").value;
    const projectDepartmentReferenceNo = document.querySelector("input[name=project-reference-department-no]").value;
    const projectCreator = document.querySelector("input[name=project-creator]").value;
    const projectManager = document.querySelector("input[name=project-manager]").value;
    const projectPriority = document.querySelector("select[name=project-priority]").value;
    const projectStatus = document.querySelector("select[name=project-status]").value;
    const projectEndedDate = document.querySelector("input[name=project-ended-date]").value;

    const vo = {
        projectDepartmentNo,
        projectDepartmentReferenceNo,
        projectPriority,
        projectStatus,
        projectName,
        projectCreator,
        projectManager,
        projectEndedDate
    };
    
    
    const url = "http://127.0.0.1:8080/api/project";
    const option = {
        method : "POST",
        headers : {
            "Content-Type" : "application/json"
        },
        body : JSON.stringify(vo),
    };

    fetch(url,option)
    .then(resp => resp.json())
    .then(result =>{
        if(result == 1){
            alert("프로젝트 등록 성공!!");
            location.href = "/project/list";
        }
    })
    .catch(err =>{
        throw new Error();
    })
    ;
}