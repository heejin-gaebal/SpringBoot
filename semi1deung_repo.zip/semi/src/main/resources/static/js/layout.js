document.querySelectorAll('#sidebar > ul > li > a').forEach(aTag => {
    aTag.addEventListener('click', function() {
        this.parentNode.classList.toggle('active');
    });
});