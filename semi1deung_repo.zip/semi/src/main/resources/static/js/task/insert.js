function taskInsert(){
    const taskName = document.querySelector("input[name=task-name]").value;
    // const taskProjectNo = document.querySelector("input[name=task_project_no]").value;
    const taskParentNo = document.querySelector("input[name=task-parent-no]").value;
    const taskDepartmentNo = document.querySelector("input[name=task-department-no]").value;
    const taskCreator = document.querySelector("input[name=task-creator]").value;
    const taskManager = document.querySelector("input[name=task-manager]").value;
    const taskPriority = document.querySelector("select[name=task-priority]").value;
    const taskStatus = document.querySelector("select[name=task-status]").value;
    // const taskCreatedDate = document.querySelector("input[name=task-created-date]").value;
    const taskEndedDate = document.querySelector("input[name=task-ended-date]").value;
    // const taskDepartmentReferenceNo = document.querySelector("input[name=task-reference-department-no]").value;

    const vo = {
        taskName,
        // taskProjectNo,
        taskParentTaskNo: taskParentNo || null,
        taskDepartmentNo,
        taskCreator,
        taskManager,
        taskPriority,
        taskStatus,
        taskEndedDate,
    };

    const url = "http://127.0.0.1:8080/api/task";
    const option = {
        method : "POST",
        headers : {
            "Content-Type" : "application/json"
        },
        body : JSON.stringify(vo),
    };

    fetch(url,option)
    .then(resp => resp.json())
    .then(result =>{
        if(result == 1){
            alert("테스크 등록 성공!!");
            location.href = "/task/list/1";
        }
    })
    .catch(err =>{
        throw new Error();
    })
    ;
}