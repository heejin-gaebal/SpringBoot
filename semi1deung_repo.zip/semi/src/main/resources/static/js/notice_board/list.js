function noticeList(){

    const url = "http://127.0.0.1:8080/api/notice_board";
    fetch(url)
    .then(resp => resp.json())
    .then( voList => {
        const tbody = document.querySelector("#container table > tbody");
        let str = "";
        for(const vo of voList){
            str += `
                <tr onclick="">
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            `
        }

    })
}
noticeList();