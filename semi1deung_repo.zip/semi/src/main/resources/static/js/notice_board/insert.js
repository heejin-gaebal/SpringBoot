function noticeInsert(){
    const noticeTitle = document.querySelector("input[name=noticeTitle]").value; 
    const noticeCreatedDate = document.querySelector("input[name=noticeCreatedDate]").value; 
    const noticeContent = document.querySelector("textarea[name=noticeContent]").value;
    const vo = {
        noticeTitle,
        noticeCreatedDate,
        noticeContent
    };
    const url = "http://127.0.0.1:8080/api/notice_board";
    const option = {
        method : "post",
        headers : {
            "Content-Type" : "application/json"
        },
        body : JSON.stringify(vo),
    };
    fetch(url , option)
    .then(resp=> resp.json())
    .then(result=> {
        if(result == 1){
            alert("공지사항 등록 완료");
            location.href='/notice_board/list';
        }else{
            alert("공지사항 등록 실패");
            location.reload();
        }
    })
}