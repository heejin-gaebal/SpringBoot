function insert(){
    
    const title = document.querySelector("input[name=title]").value;
    const content = document.querySelector("textarea[name=content]").value;
    const categoryNo = document.querySelector("select[name=categoryNo]").value;

    const fd = new FormData();
    fd.append("title", title);
    fd.append("content", content);
    fd.append("categoryNo", categoryNo);

    const url ="http://127.0.0.1:8080/api/board";
    const option ={
        method : "post",
        body : fd,
    };
    fetch(url , option)
    .then(resp => {
        if(!resp.ok){
            throw new Error();
        }
        return resp.json();
    })
    .then(result => {
        if(result == 1){
            alert("게시글 등록 성공!!");
            location.href="/board/list";
        }else{
            alert("게시글 등록 실퍀ㅋㅋ");
            // location.reload();
        }
    });
    return false; //얘가 있어야 form태그의 기본이벤트 submit가 작동X
}

function showCategoryList(){
    const url ="http://127.0.0.1:8080/api/board/category";
    fetch(url)
    .then(resp => {
        if(!resp.ok){
            throw new Error("HTTP STATUS NOT OK");
        }else{
            return resp.json();
        }
    })
    .then(voList => {
        const selectTag = document.querySelector("select[name=categoryNo]");
        let str = "";
        for(const vo of voList){
            str += `
                <option value="${vo.no}">${vo.name}</option>
            `;
        }
        selectTag.innerHTML = str;
    })
    .catch(err=>{
        console.log(err);
    })
}
showCategoryList();