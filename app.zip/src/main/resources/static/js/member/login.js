function login(){
    const id = document.querySelector("input[name=id]").value;
    const pwd = document.querySelector("input[name=pwd]").value;
    const vo = {
        id,
        pwd,
    };
    const url = "http://127.0.0.1:8080/api/member/login";
    const option = {
        method : "post",
        headers : {
            "Content-Type" : "application/json"
        },
        body : JSON.stringify(vo),
    };
    fetch(url , option)
    .then (resp => {
        if(!resp.ok){//resp코드가 ok가 아닐 때
            throw new Error();
        }
        return resp.json();
    })
    .then (loginMember => {
        if (loginMember){
            alert("login success");
            location.href='/home';
        }else{
            throw new Error();
        }
    })
    .catch(err => {
        console.log(err);
        alert("login fail...");
        location.reload();
    })
}