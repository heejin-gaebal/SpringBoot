function join(){
    const id = document.querySelector("input[name=id]").value;
    const pwd = document.querySelector("input[name=pwd]").value;
    const nick = document.querySelector("input[name=nick]").value;
    const fileInput = document.querySelector("input[name=f]");
    const profile = fileInput.files[0];

    const fd = new FormData();
    fd.append("id", id);
    fd.append("pwd", pwd);
    fd.append("nick", nick);
    fd.append("f", profile);

    const url = "http://127.0.0.1:8080/api/member";
    const option = {
        method : "post",
        body : fd, //파일업로드
    };
    fetch(url , option)
    .then (resp => resp.json())
    .then (result => {
        if (result == 1){
            alert("join success");
            location.href='/member/login';
        }else{
            alert("join fail...");
            location.reload();
        }
        console.log(result);
    })
}

function showPreview(){
    const fileInput = document.querySelector("input[name=f]");
    const profilePreview = document.querySelector("#profile-preview");
    const f = fileInput.files[0];

    const fr = new FileReader();
    fr.onload = (e)=>{
        profilePreview.src = e.target.result;
    };
    fr.readAsDataURL(f);
}