package com.swy.app.board.api;

import com.swy.app.board.service.BoardService;
import com.swy.app.board.vo.BoardVo;
import com.swy.app.board.vo.CategoryVo;
import com.swy.app.member.vo.MemberVo;
import com.swy.app.util.page.PageVo;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/board")
@RequiredArgsConstructor
public class BoardApiController {
    private final BoardService boardService;

    //게시글 등록
    @PostMapping                         //파일 첨부할거라 formdata 쓸 것이므로 @Requestbody 생략
    public ResponseEntity<Integer> insert(BoardVo vo, HttpSession session, List<MultipartFile> fileList){
        MemberVo loginMember = (MemberVo) session.getAttribute("loginMember");
        String writerNo = loginMember.getNo();
        vo.setWriterNo(writerNo);

        int result = boardService.insert(vo);

        if(result != 1){          //서버측 에러
            return ResponseEntity.internalServerError().body(result);
        }

        return ResponseEntity.ok().body(result);
    }
    
    //카테고리 리스트만들기
    @GetMapping("category")
    public ResponseEntity<List<CategoryVo>> getCategoryAll(){
        List<CategoryVo> voList = boardService.getCategoryAll();

        return ResponseEntity.ok().body(voList);
    }

    //페이징 넣기
    @GetMapping("{currentPage}")
    public ResponseEntity<Map<String, Object>> getBoardAll(@PathVariable int currentPage){
        int listCount = boardService.getBoardCnt();
        int pageLimit = 5;
        int boardLimit = 10;

        PageVo pvo = new PageVo(listCount, currentPage, pageLimit, boardLimit);
        List<BoardVo> voList =  boardService.getBoardAll(pvo);

        Map<String, Object> map = new HashMap<>();
        map.put("voList", voList);
        map.put("pvo", pvo);
        return ResponseEntity.ok().body(map);
    }
}
