package com.swy.app.board.service;

import com.swy.app.board.mapper.BoardMapper;
import com.swy.app.board.vo.BoardVo;
import com.swy.app.board.vo.CategoryVo;
import com.swy.app.util.page.PageVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class BoardService {
    private final BoardMapper boardMapper;

    public int insert(BoardVo vo) {
        return boardMapper.insert(vo);
    }

    public List<CategoryVo> getCategoryAll() {
        return boardMapper.getCategoryAll();
    }

    public List<BoardVo> getBoardAll(PageVo pvo) {
        return boardMapper.getBoardAll(pvo);
    }

    public int getBoardCnt() {
        return boardMapper.getBoardCnt();
    }
}
