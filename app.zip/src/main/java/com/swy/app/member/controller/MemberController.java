package com.swy.app.member.controller;

import com.swy.app.member.vo.MemberVo;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("member")
public class MemberController {

    //회원가입
    @GetMapping("join")
    public void join(){}

    //로그인
    @GetMapping("login")
    public void login(){}

    //마이페이지
    @GetMapping("mypage")
    public String mypage(HttpSession session){
        MemberVo loginMember = (MemberVo) session.getAttribute("loginMember");
        if(loginMember == null){
            return "redirect:/member/login";
        }
        return "/member/mypage";
    }

    //로그아웃
    @GetMapping("logout")
    public String logout(HttpSession session){
        session.invalidate();
        return "redirect:/home";
    }
}
