package com.swy.app.member.api;

import com.swy.app.member.service.MemberService;
import com.swy.app.member.vo.MemberVo;
import com.swy.app.util.file.FileUploader;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@RestController
@RequestMapping("api/member")
@RequiredArgsConstructor
public class MemberApiController {
    private final MemberService memberService;

    @Value("${upload.path.member}")
    private String profilePath;

    //회원가입
    @PostMapping //폼데이터로 받는 경우는 @RequestBody 사용X!!
    public ResponseEntity<Integer> join(MemberVo vo, MultipartFile f) throws IOException {
        
        //서버저장 -> 이름 바꾸기 changeName [FileUploader.java]
        //vo에 파일명담기 파일 경로는 application.properties에 지정
        String dirPath = "D:\\dev\\spring_boot_repo\\app\\src\\main\\resources\\static\\upload\\profile\\";
        if(f != null){
            String changeName = FileUploader.save(f, dirPath);
            vo.setProfile(changeName);
        }else{
            vo.setProfile("user.png");
        }

        //service
        int result = memberService.join(vo);
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(result);
        //HTTP 200 OK 상태와 함께 result 내용을 응답으로 반환
        //Map에 묶어서 리턴했던 status와 데이터를 한번에 처리하는 구문
        //body메서드에 result  담아 보내는 것이
        //패킷의 바디에 데이터를 담아 보내는 것과 비슷 | 패치함수와의 body와 무관
    }

    @PostMapping ("login")
    public ResponseEntity<MemberVo> login(@RequestBody MemberVo vo, HttpSession session){
        MemberVo loginMember = memberService.login(vo);

        if(loginMember ==  null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        //세션에 파일담기
        loginMember.setSavePath(profilePath + loginMember.getProfile()); //경로 + changeName
        session.setAttribute("loginMember", loginMember);

        return ResponseEntity.ok().body(loginMember);
    }

    //마이페이지
    @GetMapping
    public ResponseEntity<MemberVo> selectMember(HttpSession session){
        MemberVo loginMember = (MemberVo) session.getAttribute("loginMember");
        if(loginMember == null){
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok().body(loginMember); //생략법
    }

    //회원 정보수정
    @PutMapping
    public ResponseEntity<Integer> edit(MemberVo vo, HttpSession session, MultipartFile f) throws IOException {
        MemberVo loginMember = (MemberVo) session.getAttribute("loginMember");
        String no = loginMember.getNo();
        vo.setNo(no);

        String dirPath = "D:\\dev\\spring_boot_repo\\app\\src\\main\\resources\\static\\upload\\profile\\";
        String changeName = FileUploader.save(f,dirPath);
        vo.setProfile(changeName);
        int result = memberService.edit(vo);

        if(result != 1){
            throw new IllegalStateException();
        }
        session.invalidate();
        return ResponseEntity.ok().body(result);
    }

    //회원탈퇴
    @DeleteMapping
    public ResponseEntity<Integer> quit(HttpSession session){
        MemberVo loginMember = (MemberVo) session.getAttribute("loginMember");
        String no = loginMember.getNo();
        int result = memberService.quit(no);
        if(result != 1){
            throw new IllegalStateException();
        }
        session.removeAttribute("loginMember"); //해당 세션만 삭제
        return ResponseEntity.ok().body(result);
    }
}
